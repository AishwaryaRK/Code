package com.ak.gojek.parkinglotsystem.parkinglot;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ak.gojek.parkinglotsystem.car.Car;
import com.ak.gojek.parkinglotsystem.colour.Colour;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;

public class ParkingLotTest {
	private static final int PARKING_LOT_CAPACITY = 3;
	private static final int NOT_FOUND = 0;
	private ParkingLot parkingLot;

	@Before
	public void setUp() throws Exception {
		parkingLot = new ParkingLot(PARKING_LOT_CAPACITY);
	}

	@After
	public void tearDown() throws Exception {
		parkingLot = null;
	}

	@Test
	public void testPark() {
		Car car = new Car("KA-­01-­HH-­1234", Colour.WHITE);
		ParkingSlot parkingSlot = parkingLot.park(car);
		assertTrue(parkingSlot.getSlotNumber() == 1);
		parkingSlot = parkingLot.park(car);
		assertTrue(parkingSlot.getSlotNumber() == 2);
		parkingSlot = parkingLot.park(car);
		assertTrue(parkingSlot.getSlotNumber() == 3);
		parkingSlot = parkingLot.park(car);
		assertNull(parkingSlot);
	}

	@Test
	public void testLeaveCar() {
		Car car = new Car("KA-­01-­HH-­1234", Colour.WHITE);
		ParkingSlot parkingSlot = parkingLot.park(car);
		assertTrue(parkingLot.leaveCar(parkingSlot.getSlotNumber()));
		assertFalse(parkingLot.leaveCar(PARKING_LOT_CAPACITY + 1));
	}

	@Test
	public void testGetRegistrationNumbersForCarsWithColour() {
		Car car = new Car("KA-­01-­HH-­1234", Colour.WHITE);
		parkingLot.park(car);
		car = new Car("MH-­12-­FG-­3124", Colour.BLACK);
		parkingLot.park(car);
		car = new Car("TN-­41-­SE-­6565", Colour.WHITE);
		parkingLot.park(car);
		List<String> expectedRegistrationNumbersForCars = new ArrayList<String>();
		expectedRegistrationNumbersForCars.add("KA-­01-­HH-­1234");
		expectedRegistrationNumbersForCars.add("TN-­41-­SE-­6565");
		List<String> actualRegistrationNumbersForCars = parkingLot
				.getRegistrationNumbersForCarsWithColour(Colour.WHITE);
		assertTrue(expectedRegistrationNumbersForCars.equals(actualRegistrationNumbersForCars));
	}

	@Test
	public void testGetSlotNumbersForCarsWithColour() {
		Car car = new Car("KA-­01-­HH-­1234", Colour.WHITE);
		parkingLot.park(car);
		car = new Car("MH-­12-­FG-­3124", Colour.BLACK);
		parkingLot.park(car);
		car = new Car("TN-­41-­SE-­6565", Colour.WHITE);
		parkingLot.park(car);
		List<Integer> expectedSlotNumbersForCarsWithColour = new ArrayList<Integer>();
		expectedSlotNumbersForCarsWithColour.add(1);
		expectedSlotNumbersForCarsWithColour.add(3);
		List<Integer> actualSlotNumbersForCarsWithColour = parkingLot.getSlotNumbersForCarsWithColour(Colour.WHITE);
		assertTrue(expectedSlotNumbersForCarsWithColour.equals(actualSlotNumbersForCarsWithColour));
	}

	@Test
	public void testGetSlotNumberForRegistrationNumber() {
		Car car = new Car("KA-­01-­HH-­1234", Colour.WHITE);
		parkingLot.park(car);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("KA-­01-­HH-­1234") == 1);
		car = new Car("MH-­12-­FG-­3124", Colour.BLACK);
		parkingLot.park(car);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("MH-­12-­FG-­3124") == 2);
		car = new Car("TN-­41-­SE-­6565", Colour.WHITE);
		parkingLot.park(car);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("TN-­41-­SE-­6565") == 3);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("AP-­01-­WH-­5534") == NOT_FOUND);
	}

	@Test
	public void testGetStatus() {
		Car car = new Car("KA-­01-­HH-­1234", Colour.WHITE);
		parkingLot.park(car);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("KA-­01-­HH-­1234") == 1);
		car = new Car("MH-­12-­FG-­3124", Colour.BLACK);
		parkingLot.park(car);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("MH-­12-­FG-­3124") == 2);
		car = new Car("TN-­41-­SE-­6565", Colour.WHITE);
		parkingLot.park(car);
		assertTrue(parkingLot.getSlotNumberForRegistrationNumber("TN-­41-­SE-­6565") == 3);
		parkingLot.leaveCar(2);
		List<String> expectedParkingSlotsStatus = new ArrayList<String>();
		expectedParkingSlotsStatus.add("1\tKA-­01-­HH-­1234\tWhite");
		expectedParkingSlotsStatus.add("3\tTN-­41-­SE-­6565\tWhite");
		List<String> actualParkingSlotsStatus = parkingLot.getStatus();
		assertTrue(expectedParkingSlotsStatus.equals(actualParkingSlotsStatus));
	}

}
