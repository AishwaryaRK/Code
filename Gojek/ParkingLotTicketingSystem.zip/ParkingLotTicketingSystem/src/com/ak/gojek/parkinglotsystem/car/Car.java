package com.ak.gojek.parkinglotsystem.car;

import com.ak.gojek.parkinglotsystem.colour.Colour;

public class Car {
	private String registrationNumber;
	private Colour colour;

	public Car(String registrationNumber, Colour colour) {
		super();
		this.registrationNumber = registrationNumber;
		this.colour = colour;
	}

	public boolean isSameColour(Colour otherColour) {
		return colour.equals(otherColour);
	}

	public boolean isSameRegistrationNumber(String otherRegistrationNumber) {
		return registrationNumber.equals(otherRegistrationNumber);
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	private void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public Colour getColour() {
		return colour;
	}

	private void setColour(Colour colour) {
		this.colour = colour;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((colour == null) ? 0 : colour.hashCode());
		result = prime * result + ((registrationNumber == null) ? 0 : registrationNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (registrationNumber == null) {
			if (other.registrationNumber != null)
				return false;
		} else if (!registrationNumber.equals(other.registrationNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Car [registrationNumber=");
		builder.append(registrationNumber);
		builder.append(", colour=");
		builder.append(colour);
		builder.append("]");
		return builder.toString();
	}

}
