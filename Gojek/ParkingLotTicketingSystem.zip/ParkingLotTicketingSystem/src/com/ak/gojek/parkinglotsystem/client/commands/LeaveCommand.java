package com.ak.gojek.parkinglotsystem.client.commands;

import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;

public class LeaveCommand extends Command {

	@Override
	public void executeCommand(ParkingLot parkingLot, String command) {
		int parkingSlotNumber = Integer.parseInt(command.split(" ")[1]);
		if (parkingLot.leaveCar(parkingSlotNumber)) {
			System.out.println("Slot number " + parkingSlotNumber + " is free");
		} else {
			System.out.println("Invalid parking slot number");
		}
	}

}
