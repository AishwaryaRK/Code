package com.ak.gojek.parkinglotsystem.client.commands;

import java.util.List;

import com.ak.gojek.parkinglotsystem.colour.Colour;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;

public class RegistrationNumbersForCarsWithColourCommand extends Command {

	@Override
	public void executeCommand(ParkingLot parkingLot, String command) {
		Colour colour = Colour.valueOf(command.split(" ")[1].toUpperCase());
		List<String> registrationNumbersForCarsWithColour = parkingLot.getRegistrationNumbersForCarsWithColour(colour);
		if (registrationNumbersForCarsWithColour.size() > 0) {
			for (int i = 0; i < registrationNumbersForCarsWithColour.size() - 1; i++) {
				System.out.print(registrationNumbersForCarsWithColour.get(i) + ", ");
			}
			System.out
					.println(registrationNumbersForCarsWithColour.get(registrationNumbersForCarsWithColour.size() - 1));
		}
	}

}
