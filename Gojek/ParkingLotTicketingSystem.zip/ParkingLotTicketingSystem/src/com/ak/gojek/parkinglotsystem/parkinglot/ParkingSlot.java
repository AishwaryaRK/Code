package com.ak.gojek.parkinglotsystem.parkinglot;

import com.ak.gojek.parkinglotsystem.car.Car;
import com.ak.gojek.parkinglotsystem.colour.Colour;

public class ParkingSlot implements Comparable<ParkingSlot> {
	private int slotNumber;
	private Car parkedCar;

	public ParkingSlot(int slotNumber) {
		super();
		this.slotNumber = slotNumber;
		this.parkedCar = null;
	}

	public boolean isAvailable() {
		return getParkedCar() == null;
	}
	
	public void empty() {
		setParkedCar(null);
	}

	public boolean isParkedCarColourSame(Colour colour) {
		return this.parkedCar.isSameColour(colour);
	}

	public String getParkedCarRegistrationNumber() {
		return this.parkedCar.getRegistrationNumber();
	}

	public boolean isParkedCarRegistrationNumberSame(String carRegistrationNumber) {
		return this.parkedCar.isSameRegistrationNumber(carRegistrationNumber);
	}

	public String getStatus() {
		if (isAvailable()) {
			return Integer.toString(getSlotNumber());
		}
		return getSlotNumber() + "\t" + this.parkedCar.getRegistrationNumber() + "\t"
				+ this.parkedCar.getColour().getValue();
	}

	public int getSlotNumber() {
		return slotNumber;
	}

	private void setSlotNumber(int slotNumber) {
		this.slotNumber = slotNumber;
	}

	public Car getParkedCar() {
		return parkedCar;
	}

	public void setParkedCar(Car car) {
		this.parkedCar = car;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + slotNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParkingSlot other = (ParkingSlot) obj;
		if (slotNumber != other.slotNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ParkingSlot [slotNumber=");
		builder.append(slotNumber);
		builder.append(", car=");
		builder.append(parkedCar);
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int compareTo(ParkingSlot otherParkingSlot) {
		return Integer.compare(getSlotNumber(), otherParkingSlot.getSlotNumber());
	}

}
