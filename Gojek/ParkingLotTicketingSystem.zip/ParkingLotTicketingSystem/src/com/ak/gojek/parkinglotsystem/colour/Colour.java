package com.ak.gojek.parkinglotsystem.colour;

public enum Colour {
	WHITE("White"), BLACK("Black"), BLUE("Blue"), RED("Red"), SILVER("Silver"), GREEN("Green"), YELLOW(
			"Yellow"), ORANGE("Orange");

	private String value;

	private Colour(String colour) {
		this.value = colour;
	}

	public String getValue() {
		return value;
	}
}
