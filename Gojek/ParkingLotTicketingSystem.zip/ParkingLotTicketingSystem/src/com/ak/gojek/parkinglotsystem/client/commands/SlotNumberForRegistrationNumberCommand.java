package com.ak.gojek.parkinglotsystem.client.commands;

import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;

public class SlotNumberForRegistrationNumberCommand extends Command {

	private static final int NOT_FOUND = 0;

	@Override
	public void executeCommand(ParkingLot parkingLot, String command) {
		String carRegistrationNumber = command.split(" ")[1];
		int slotNumber = parkingLot.getSlotNumberForRegistrationNumber(carRegistrationNumber);
		if (slotNumber == NOT_FOUND) {
			System.out.println("Not found");
		} else {
			System.out.println(slotNumber);
		}
	}

}
