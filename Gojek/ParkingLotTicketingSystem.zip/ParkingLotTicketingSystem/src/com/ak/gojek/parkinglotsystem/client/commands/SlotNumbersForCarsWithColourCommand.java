package com.ak.gojek.parkinglotsystem.client.commands;

import java.util.List;

import com.ak.gojek.parkinglotsystem.colour.Colour;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;

public class SlotNumbersForCarsWithColourCommand extends Command {

	@Override
	public void executeCommand(ParkingLot parkingLot, String command) {
		Colour colour = Colour.valueOf(command.split(" ")[1].toUpperCase());
		List<Integer> slotNumbersForCarsWithColour = parkingLot.getSlotNumbersForCarsWithColour(colour);
		if (slotNumbersForCarsWithColour.size() > 0) {
			for (int i = 0; i < slotNumbersForCarsWithColour.size() - 1; i++) {
				System.out.print(slotNumbersForCarsWithColour.get(i) + ", ");
			}
			System.out.println(slotNumbersForCarsWithColour.get(slotNumbersForCarsWithColour.size() - 1));
		}
	}

}
