package com.ak.gojek.parkinglotsystem.client.commands;

import com.ak.gojek.parkinglotsystem.car.Car;
import com.ak.gojek.parkinglotsystem.colour.Colour;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingSlot;

public class ParkCommand extends Command {
	@Override
	public void executeCommand(ParkingLot parkingLot, String command) {
		String[] splittedCommand = command.split(" ");
		String carRegistrationNumber = splittedCommand[1];
		Colour colour = Colour.valueOf(splittedCommand[2].toUpperCase());
		Car car = new Car(carRegistrationNumber, colour);
		ParkingSlot parkingSlot = parkingLot.park(car);
		if (parkingSlot == null) {
			System.out.println("Sorry, parking lot is full");
		} else {
			System.out.println("Allocated slot number: " + parkingSlot.getSlotNumber());
		}
	}
}