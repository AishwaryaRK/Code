package com.ak.gojek.parkinglotsystem.client.commands;

import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;

public abstract class Command {
	public abstract void executeCommand(ParkingLot parkingLot, String command);
}
