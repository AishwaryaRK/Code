package com.ak.gojek.parkinglotsystem.client.commands;

import java.util.List;

import com.ak.gojek.parkinglotsystem.car.Car;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingLot;
import com.ak.gojek.parkinglotsystem.parkinglot.ParkingSlot;

public class StatusCommand extends Command {

	@Override
	public void executeCommand(ParkingLot parkingLot, String command) {
		List<String> parkingSlotsStatus = parkingLot.getStatus();
		if (parkingSlotsStatus.isEmpty()) {
			System.out.println("Parking lot is empty");
		}
		System.out.println("Slot No.\tRegistration No\tColour");
		for (String parkingSlotStatus : parkingSlotsStatus) {
			System.out.println(parkingSlotStatus);
		}
	}

}
